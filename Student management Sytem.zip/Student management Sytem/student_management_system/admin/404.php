<div class="text-center text-danger">
<img style="width:100%;" src="images/images.jpg" alt="404 error not found">
</div>