<?php 
 $link =  mysqli_connect("localhost","root","","school_manage");
?>